//: Playground - noun: a place where people can play
import UIKit

var str = "hello world"
print(str)
print("hello")

let a=1
let b
= 2
+ 3
+ 4
let ans = a + b

let product = ("swift", 2014)
var kingaku = (1000,80)
